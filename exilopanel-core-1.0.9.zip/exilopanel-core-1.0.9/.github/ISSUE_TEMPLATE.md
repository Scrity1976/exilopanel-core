For support, please use our forums: http://forums.sentora.org/, you can search for solutions there.
Feel free to open a new question if none of the threads solve your problem.
Please, do NOT use this issue tracker for support.

For bug reports please provide the following information:

Operating System:

Operating System Version number:

Sentora Version:

Issue:

How to reproduce it:

Suggested fix or solution if you have any:


Thank you on the behalf of the Sentora Team.

V 0.0.2
